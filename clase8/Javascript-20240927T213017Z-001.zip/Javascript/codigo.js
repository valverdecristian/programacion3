//JAVASCRIPT

// VARIABLES : var - let -  const

/* var nombre;
let apellido;
const URL; */

/* camel case */

/* let nombreEscuela = "Nicolino";   */ /* uppercamelcase */
/* let Nombreescuela = "Marcela" ;   */  /*  lowercamelcase */
/* let nombre_escuela  = "Natalio"; */

/* let apellido;

const URL = "https://www.google.com/" */
/* URL = "https://www.google.com.ar/"
 */
/* nombreEscuela = 145;  */ /* cambio el valor de la variable */

/* case sensitive */
/* formado con letras numeros y simbolos $ _ (guion bajo)
    no pueden empezar con un numeros y no deberian contener ñ o carateres especiales
 */

/* console.log(URL); */


// tipos de datos

/* let cadena = "esto es una cadena de texto" */ /* STRING */
/* let numero = 3 *//*  NUMBER */
/* let booleano = true */ /* o false BOOLEAN */

/* interacciones (navegador) */
/*  alert ("Hola Soy JS") */  // Mensaje emergente

/*  let confirmacion = confirm ("Desea Ingresar a la WEB")  */// Confirmacion (true- false)


/* let user = prompt ("Decime tu nombre")
alert ("Hola "+ user + " como estas")
alert (2+2)
 */

/*  let num1=Number(prompt ("decime un numero"))
let num2= Number (prompt ("decime un otro numero")) */

/* let num1=(prompt ("decime un numero"))
let num2= (prompt ("decime un otro numero")) */
/* parseInt ()
parseFloat () */
/* 
alert(parseInt(true))
alert (Number(true)) */

/* "10"+"10"  = "1010" */

/* prompt = String */

/* let resultado = num1+num2 */


/* document.write("tu resultado es " + resultado ) */ // escribimos en el documento

/* document.write(typeof resultado)  *///sabemos el tipo de dato de la variable.

// operadores matematicos

console.log(21+7);/* (+  SUMA) */
console.log(21-7); /* - RESTA */
console.log(21*7); /* - MULTIPLICACION */
console.log(21/7); /* - DIVISION */
console.log(21%7); /* - MODULO */


/* operadores de comparacion */

let num1 = 32;
let num2=40;
let num3="32";
let num4= 32;

console.log(num1==num3);  /* es igual? */
console.log(num1===num3);  /* es estrictamente igual? */
console.log(num1!=num3);  /* distinto */
console.log(num1!==num3);  /* estrictamente distinto a */
console.log(num1>num2); /* mayor */
console.log(num2<num3); /* menor */
console.log(num1>=num4); /* mayor */
console.log(num1<=num2); /* mayor */


/* OR     AND */
/*     ||     &&    */   

                     /* OR */
console.log(num1==num3||num1>num2);
     /*      true   || false        */
     
  
              /*AND */
console.log(num1==num3&& num1>num2);
      /*      true   || false        */

    

 /*  console.log("Hola" + " " + nombre + " "+ apellido); */
/* 
  plantillas literales
  backstick */

/*   `` */ 
/*   Altgr+} */
/* 
  `` */ /* alt + 96 */

let nombre = "Gustavo"
let apellido =  "Ballas"

/* ${} */
console.log(`hola como estas? ${nombre} tu apellido es ${apellido} `);

      

    














